package a;

final class r
  implements m<TResult, o<TContinuationResult>>
{
  r(o paramo, i parami, m paramm) {}
  
  public o<TContinuationResult> a(o<TResult> paramo)
  {
    if ((this.a != null) && (this.a.a())) {
      return o.i();
    }
    if (paramo.e()) {
      return o.a(paramo.g());
    }
    if (paramo.d()) {
      return o.i();
    }
    return paramo.a(this.b);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\a\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */