package a;

public final class n
  extends RuntimeException
{
  public n(Exception paramException)
  {
    super("An exception was thrown by an Executor", paramException);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\a\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */