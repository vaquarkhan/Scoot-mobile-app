package a;

public final class l<T>
{
  private T a;
  
  public l() {}
  
  public l(T paramT)
  {
    this.a = paramT;
  }
  
  public T a()
  {
    return (T)this.a;
  }
  
  public void a(T paramT)
  {
    this.a = paramT;
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\a\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */