package a;

final class ad
{
  private o<?> a;
  
  public ad(o<?> paramo)
  {
    this.a = paramo;
  }
  
  public void a()
  {
    this.a = null;
  }
  
  protected void finalize()
  {
    try
    {
      o localo = this.a;
      if (localo != null)
      {
        ab localab = o.a();
        if (localab != null) {
          localab.a(localo, new ae(localo.g()));
        }
      }
      return;
    }
    finally
    {
      super.finalize();
    }
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\a\ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */