package a;

public abstract interface m<TTaskResult, TContinuationResult>
{
  public abstract TContinuationResult then(o<TTaskResult> paramo);
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\a\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */