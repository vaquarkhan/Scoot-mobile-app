package a;

import java.util.Locale;

public final class i
{
  private final k a;
  
  public boolean a()
  {
    return this.a.a();
  }
  
  public String toString()
  {
    return String.format(Locale.US, "%s@%s[cancellationRequested=%s]", new Object[] { getClass().getName(), Integer.toHexString(hashCode()), Boolean.toString(this.a.a()) });
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\a\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */