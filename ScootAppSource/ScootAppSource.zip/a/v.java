package a;

final class v
  implements m<TContinuationResult, Void>
{
  v(u paramu) {}
  
  public Void a(o<TContinuationResult> paramo)
  {
    if ((this.a.a != null) && (this.a.a.a()))
    {
      this.a.b.c();
      return null;
    }
    if (paramo.d())
    {
      this.a.b.c();
      return null;
    }
    if (paramo.e())
    {
      this.a.b.b(paramo.g());
      return null;
    }
    this.a.b.b(paramo.f());
    return null;
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\a\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */