package a;

final class w
  implements m<TResult, o<Void>>
{
  w(o paramo) {}
  
  public o<Void> a(o<TResult> paramo)
  {
    if (paramo.d()) {
      return o.i();
    }
    if (paramo.e()) {
      return o.a(paramo.g());
    }
    return o.a(null);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\a\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */