package a;

import java.util.concurrent.Callable;
import java.util.concurrent.Executor;

final class z
  implements m<Void, o<Void>>
{
  z(o paramo, i parami, Callable paramCallable, m paramm, Executor paramExecutor, l paraml) {}
  
  public o<Void> a(o<Void> paramo)
  {
    if ((this.a != null) && (this.a.a())) {
      return o.i();
    }
    if (((Boolean)this.b.call()).booleanValue()) {
      return o.a(null).d(this.c, this.d).d((m)this.e.a(), this.d);
    }
    return o.a(null);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\a\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */