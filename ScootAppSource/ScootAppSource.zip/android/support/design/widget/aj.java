package android.support.design.widget;

final class aj
  extends ai
{
  private aj(af paramaf)
  {
    super(paramaf, null);
  }
  
  protected float a()
  {
    return this.b.f + this.b.g;
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\aj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */