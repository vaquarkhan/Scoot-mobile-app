package android.support.design.widget;

import android.support.v4.view.ff;
import android.view.View;

final class bz
  extends ff
{
  bz(TextInputLayout paramTextInputLayout) {}
  
  public void a(View paramView)
  {
    paramView.setVisibility(0);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\bz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */