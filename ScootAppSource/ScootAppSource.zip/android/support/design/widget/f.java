package android.support.design.widget;

import android.os.Parcel;

final class f
  implements android.support.v4.e.f<AppBarLayout.Behavior.SavedState>
{
  public AppBarLayout.Behavior.SavedState a(Parcel paramParcel, ClassLoader paramClassLoader)
  {
    return new AppBarLayout.Behavior.SavedState(paramParcel, paramClassLoader);
  }
  
  public AppBarLayout.Behavior.SavedState[] a(int paramInt)
  {
    return new AppBarLayout.Behavior.SavedState[paramInt];
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */