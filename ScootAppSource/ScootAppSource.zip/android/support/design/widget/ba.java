package android.support.design.widget;

import android.view.View;
import android.view.View.OnClickListener;

final class ba
  implements View.OnClickListener
{
  ba(Snackbar paramSnackbar, View.OnClickListener paramOnClickListener) {}
  
  public void onClick(View paramView)
  {
    this.a.onClick(paramView);
    Snackbar.a(this.b, 1);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\ba.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */