package android.support.design.widget;

import android.view.View;

final class db
  implements da
{
  public void a(View paramView) {}
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\db.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */