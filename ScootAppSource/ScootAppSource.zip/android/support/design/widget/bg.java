package android.support.design.widget;

import android.support.v4.view.ff;
import android.view.View;

final class bg
  extends ff
{
  bg(Snackbar paramSnackbar) {}
  
  public void a(View paramView)
  {
    Snackbar.b(this.a).a(70, 180);
  }
  
  public void b(View paramView)
  {
    Snackbar.e(this.a);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\bg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */