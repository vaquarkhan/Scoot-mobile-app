package android.support.design.widget;

import android.view.View;

final class bc
  implements bv
{
  bc(Snackbar paramSnackbar) {}
  
  public void a(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return;
    case 1: 
    case 2: 
      bn.a().c(Snackbar.a(this.a));
      return;
    }
    bn.a().d(Snackbar.a(this.a));
  }
  
  public void a(View paramView)
  {
    paramView.setVisibility(8);
    Snackbar.a(this.a, 0);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\bc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */