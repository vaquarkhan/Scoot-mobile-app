package android.support.design.widget;

final class cg
  implements cl
{
  cg(cf paramcf, ch paramch) {}
  
  public void a()
  {
    this.a.a(this.b);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\cg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */