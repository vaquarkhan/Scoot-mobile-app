package android.support.design.widget;

public abstract class e
{
  public abstract boolean a(AppBarLayout paramAppBarLayout);
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */