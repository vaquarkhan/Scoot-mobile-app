package android.support.design.widget;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;

final class cp
  implements ValueAnimator.AnimatorUpdateListener
{
  cp(co paramco, cl paramcl) {}
  
  public void onAnimationUpdate(ValueAnimator paramValueAnimator)
  {
    this.a.a();
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\cp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */