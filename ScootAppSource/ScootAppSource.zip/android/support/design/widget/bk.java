package android.support.design.widget;

public abstract class bk
{
  public void a(Snackbar paramSnackbar) {}
  
  public void a(Snackbar paramSnackbar, int paramInt) {}
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\bk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */