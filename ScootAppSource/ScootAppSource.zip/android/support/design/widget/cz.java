package android.support.design.widget;

import android.os.Build.VERSION;

final class cz
  implements ci
{
  public cf a()
  {
    if (Build.VERSION.SDK_INT >= 12) {}
    for (Object localObject = new co();; localObject = new cm()) {
      return new cf((cj)localObject);
    }
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\cz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */