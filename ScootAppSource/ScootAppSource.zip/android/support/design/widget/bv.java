package android.support.design.widget;

import android.view.View;

public abstract interface bv
{
  public abstract void a(int paramInt);
  
  public abstract void a(View paramView);
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\bv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */