package android.support.design.widget;

import android.support.v4.view.ff;
import android.view.View;
import android.widget.TextView;

final class ca
  extends ff
{
  ca(TextInputLayout paramTextInputLayout, CharSequence paramCharSequence) {}
  
  public void b(View paramView)
  {
    TextInputLayout.b(this.b).setText(this.a);
    paramView.setVisibility(4);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\ca.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */