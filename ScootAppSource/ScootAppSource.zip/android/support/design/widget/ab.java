package android.support.design.widget;

final class ab
  implements aq
{
  ab(FloatingActionButton paramFloatingActionButton, ad paramad) {}
  
  public void a()
  {
    this.a.a(this.b);
  }
  
  public void b()
  {
    this.a.b(this.b);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */