package android.support.design.widget;

public abstract class ad
{
  public void a(FloatingActionButton paramFloatingActionButton) {}
  
  public void b(FloatingActionButton paramFloatingActionButton) {}
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */