package android.support.design.widget;

final class cn
  implements Runnable
{
  cn(cm paramcm) {}
  
  public void run()
  {
    cm.a(this.a);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\cn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */