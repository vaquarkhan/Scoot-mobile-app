package android.support.design.widget;

import android.support.v4.view.bs;
import android.support.v4.view.fh;
import android.view.View;

final class c
  implements bs
{
  c(AppBarLayout paramAppBarLayout) {}
  
  public fh a(View paramView, fh paramfh)
  {
    return AppBarLayout.a(this.a, paramfh);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */