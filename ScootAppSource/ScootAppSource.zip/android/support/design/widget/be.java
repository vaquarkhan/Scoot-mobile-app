package android.support.design.widget;

final class be
  implements Runnable
{
  be(bd parambd) {}
  
  public void run()
  {
    Snackbar.b(this.a.a, 3);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\be.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */