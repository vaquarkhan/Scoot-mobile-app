package android.support.design.widget;

import android.support.v4.view.bs;
import android.support.v4.view.cb;
import android.view.View;

final class z
  implements y
{
  public void a(View paramView, bs parambs)
  {
    if (cb.x(paramView))
    {
      cb.a(paramView, parambs);
      paramView.setSystemUiVisibility(1280);
    }
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */