package android.support.design.widget;

import android.view.animation.Interpolator;

final class cf
{
  private final cj a;
  
  cf(cj paramcj)
  {
    this.a = paramcj;
  }
  
  public void a()
  {
    this.a.a();
  }
  
  public void a(float paramFloat1, float paramFloat2)
  {
    this.a.a(paramFloat1, paramFloat2);
  }
  
  public void a(int paramInt)
  {
    this.a.a(paramInt);
  }
  
  public void a(int paramInt1, int paramInt2)
  {
    this.a.a(paramInt1, paramInt2);
  }
  
  public void a(ch paramch)
  {
    if (paramch != null)
    {
      this.a.a(new cg(this, paramch));
      return;
    }
    this.a.a(null);
  }
  
  public void a(Interpolator paramInterpolator)
  {
    this.a.a(paramInterpolator);
  }
  
  public boolean b()
  {
    return this.a.b();
  }
  
  public int c()
  {
    return this.a.c();
  }
  
  public float d()
  {
    return this.a.d();
  }
  
  public void e()
  {
    this.a.e();
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\cf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */