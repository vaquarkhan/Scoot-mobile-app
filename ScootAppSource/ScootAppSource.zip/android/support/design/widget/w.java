package android.support.design.widget;

import android.os.Parcel;
import android.support.v4.e.f;

final class w
  implements f<CoordinatorLayout.SavedState>
{
  public CoordinatorLayout.SavedState a(Parcel paramParcel, ClassLoader paramClassLoader)
  {
    return new CoordinatorLayout.SavedState(paramParcel, paramClassLoader);
  }
  
  public CoordinatorLayout.SavedState[] a(int paramInt)
  {
    return new CoordinatorLayout.SavedState[paramInt];
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */