package android.support.design.widget;

import android.view.animation.Interpolator;

abstract class cj
{
  abstract void a();
  
  abstract void a(float paramFloat1, float paramFloat2);
  
  abstract void a(int paramInt);
  
  abstract void a(int paramInt1, int paramInt2);
  
  abstract void a(cl paramcl);
  
  abstract void a(Interpolator paramInterpolator);
  
  abstract boolean b();
  
  abstract int c();
  
  abstract float d();
  
  abstract void e();
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\cj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */