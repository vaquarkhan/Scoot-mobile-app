package android.support.design.widget;

final class cb
  implements ch
{
  cb(TextInputLayout paramTextInputLayout) {}
  
  public void a(cf paramcf)
  {
    TextInputLayout.c(this.a).b(paramcf.d());
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\cb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */