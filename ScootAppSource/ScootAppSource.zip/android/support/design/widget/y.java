package android.support.design.widget;

import android.support.v4.view.bs;
import android.view.View;

abstract interface y
{
  public abstract void a(View paramView, bs parambs);
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\widget\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */