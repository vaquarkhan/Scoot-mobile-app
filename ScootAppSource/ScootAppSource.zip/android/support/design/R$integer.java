package android.support.design;

public final class R$integer
{
  public static final int abc_config_activityDefaultDur = 2131623938;
  public static final int abc_config_activityShortDur = 2131623939;
  public static final int abc_max_action_buttons = 2131623936;
  public static final int bottom_sheet_slide_duration = 2131623940;
  public static final int cancel_button_image_alpha = 2131623941;
  public static final int design_snackbar_text_max_lines = 2131623937;
  public static final int status_bar_notification_info_maxnum = 2131623944;
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\R$integer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */