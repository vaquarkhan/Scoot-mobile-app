package android.support.design;

public final class R$bool
{
  public static final int abc_action_bar_embed_tabs = 2131427331;
  public static final int abc_action_bar_embed_tabs_pre_jb = 2131427329;
  public static final int abc_action_bar_expanded_action_views_exclusive = 2131427332;
  public static final int abc_allow_stacked_button_bar = 2131427328;
  public static final int abc_config_actionMenuItemAllCaps = 2131427333;
  public static final int abc_config_allowActionMenuItemTextWithIcon = 2131427330;
  public static final int abc_config_closeDialogWhenTouchOutside = 2131427334;
  public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 2131427335;
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\R$bool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */