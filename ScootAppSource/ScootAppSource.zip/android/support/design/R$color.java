package android.support.design;

public final class R$color
{
  public static final int abc_background_cache_hint_selector_material_dark = 2131689707;
  public static final int abc_background_cache_hint_selector_material_light = 2131689708;
  public static final int abc_color_highlight_material = 2131689709;
  public static final int abc_input_method_navigation_guard = 2131689472;
  public static final int abc_primary_text_disable_only_material_dark = 2131689710;
  public static final int abc_primary_text_disable_only_material_light = 2131689711;
  public static final int abc_primary_text_material_dark = 2131689712;
  public static final int abc_primary_text_material_light = 2131689713;
  public static final int abc_search_url_text = 2131689714;
  public static final int abc_search_url_text_normal = 2131689473;
  public static final int abc_search_url_text_pressed = 2131689474;
  public static final int abc_search_url_text_selected = 2131689475;
  public static final int abc_secondary_text_material_dark = 2131689715;
  public static final int abc_secondary_text_material_light = 2131689716;
  public static final int accent_material_dark = 2131689476;
  public static final int accent_material_light = 2131689477;
  public static final int background_floating_material_dark = 2131689482;
  public static final int background_floating_material_light = 2131689483;
  public static final int background_material_dark = 2131689484;
  public static final int background_material_light = 2131689485;
  public static final int bright_foreground_disabled_material_dark = 2131689506;
  public static final int bright_foreground_disabled_material_light = 2131689507;
  public static final int bright_foreground_inverse_material_dark = 2131689508;
  public static final int bright_foreground_inverse_material_light = 2131689509;
  public static final int bright_foreground_material_dark = 2131689510;
  public static final int bright_foreground_material_light = 2131689511;
  public static final int button_material_dark = 2131689512;
  public static final int button_material_light = 2131689513;
  public static final int design_fab_shadow_end_color = 2131689595;
  public static final int design_fab_shadow_mid_color = 2131689596;
  public static final int design_fab_shadow_start_color = 2131689597;
  public static final int design_fab_stroke_end_inner_color = 2131689598;
  public static final int design_fab_stroke_end_outer_color = 2131689599;
  public static final int design_fab_stroke_top_inner_color = 2131689600;
  public static final int design_fab_stroke_top_outer_color = 2131689601;
  public static final int design_snackbar_background_color = 2131689602;
  public static final int design_textinput_error_color_dark = 2131689603;
  public static final int design_textinput_error_color_light = 2131689604;
  public static final int dim_foreground_disabled_material_dark = 2131689613;
  public static final int dim_foreground_disabled_material_light = 2131689614;
  public static final int dim_foreground_material_dark = 2131689615;
  public static final int dim_foreground_material_light = 2131689616;
  public static final int foreground_material_dark = 2131689624;
  public static final int foreground_material_light = 2131689625;
  public static final int highlighted_text_material_dark = 2131689630;
  public static final int highlighted_text_material_light = 2131689631;
  public static final int hint_foreground_material_dark = 2131689632;
  public static final int hint_foreground_material_light = 2131689633;
  public static final int material_blue_grey_800 = 2131689639;
  public static final int material_blue_grey_900 = 2131689640;
  public static final int material_blue_grey_950 = 2131689641;
  public static final int material_deep_teal_200 = 2131689642;
  public static final int material_deep_teal_500 = 2131689643;
  public static final int material_grey_100 = 2131689644;
  public static final int material_grey_300 = 2131689645;
  public static final int material_grey_50 = 2131689646;
  public static final int material_grey_600 = 2131689647;
  public static final int material_grey_800 = 2131689648;
  public static final int material_grey_850 = 2131689649;
  public static final int material_grey_900 = 2131689650;
  public static final int primary_dark_material_dark = 2131689667;
  public static final int primary_dark_material_light = 2131689668;
  public static final int primary_material_dark = 2131689669;
  public static final int primary_material_light = 2131689670;
  public static final int primary_text_default_material_dark = 2131689671;
  public static final int primary_text_default_material_light = 2131689672;
  public static final int primary_text_disabled_material_dark = 2131689673;
  public static final int primary_text_disabled_material_light = 2131689674;
  public static final int ripple_material_dark = 2131689678;
  public static final int ripple_material_light = 2131689679;
  public static final int secondary_text_default_material_dark = 2131689680;
  public static final int secondary_text_default_material_light = 2131689681;
  public static final int secondary_text_disabled_material_dark = 2131689682;
  public static final int secondary_text_disabled_material_light = 2131689683;
  public static final int switch_thumb_disabled_material_dark = 2131689690;
  public static final int switch_thumb_disabled_material_light = 2131689691;
  public static final int switch_thumb_material_dark = 2131689729;
  public static final int switch_thumb_material_light = 2131689730;
  public static final int switch_thumb_normal_material_dark = 2131689692;
  public static final int switch_thumb_normal_material_light = 2131689693;
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\R$color.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */