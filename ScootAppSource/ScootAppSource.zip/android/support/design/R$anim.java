package android.support.design;

public final class R$anim
{
  public static final int abc_fade_in = 2131034112;
  public static final int abc_fade_out = 2131034113;
  public static final int abc_grow_fade_in_from_bottom = 2131034114;
  public static final int abc_popup_enter = 2131034115;
  public static final int abc_popup_exit = 2131034116;
  public static final int abc_shrink_fade_out_from_bottom = 2131034117;
  public static final int abc_slide_in_bottom = 2131034118;
  public static final int abc_slide_in_top = 2131034119;
  public static final int abc_slide_out_bottom = 2131034120;
  public static final int abc_slide_out_top = 2131034121;
  public static final int design_bottom_sheet_slide_in = 2131034129;
  public static final int design_bottom_sheet_slide_out = 2131034130;
  public static final int design_fab_in = 2131034131;
  public static final int design_fab_out = 2131034132;
  public static final int design_snackbar_in = 2131034133;
  public static final int design_snackbar_out = 2131034134;
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\design\R$anim.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */