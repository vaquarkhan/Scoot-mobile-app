package android.support.v4.g;

import java.util.Map;

final class b
  extends h<K, V>
{
  b(a parama) {}
  
  protected int a()
  {
    return this.a.h;
  }
  
  protected int a(Object paramObject)
  {
    return this.a.a(paramObject);
  }
  
  protected Object a(int paramInt1, int paramInt2)
  {
    return this.a.g[((paramInt1 << 1) + paramInt2)];
  }
  
  protected V a(int paramInt, V paramV)
  {
    return (V)this.a.a(paramInt, paramV);
  }
  
  protected void a(int paramInt)
  {
    this.a.d(paramInt);
  }
  
  protected void a(K paramK, V paramV)
  {
    this.a.put(paramK, paramV);
  }
  
  protected int b(Object paramObject)
  {
    return this.a.b(paramObject);
  }
  
  protected Map<K, V> b()
  {
    return this.a;
  }
  
  protected void c()
  {
    this.a.clear();
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\g\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */