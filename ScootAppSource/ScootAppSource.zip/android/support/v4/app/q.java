package android.support.v4.app;

import java.util.ArrayList;

final class q
{
  q a;
  q b;
  int c;
  Fragment d;
  int e;
  int f;
  int g;
  int h;
  ArrayList<Fragment> i;
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */