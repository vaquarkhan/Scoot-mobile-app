package android.support.v4.app;

import android.app.Notification;

class by
  extends cf
{
  public Notification a(bu parambu, bv parambv)
  {
    ci localci = new ci(parambu.a, parambu.B, parambu.b, parambu.c, parambu.h, parambu.f, parambu.i, parambu.d, parambu.e, parambu.g, parambu.o, parambu.p, parambu.q, parambu.k, parambu.l, parambu.j, parambu.n, parambu.v, parambu.C, parambu.x, parambu.r, parambu.s, parambu.t);
    bp.a(localci, parambu.u);
    bp.a(localci, parambu.m);
    return parambv.a(parambu, localci);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\by.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */