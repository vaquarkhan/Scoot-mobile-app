package android.support.v4.app;

import android.os.Bundle;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class ah
{
  public abstract Fragment.SavedState a(Fragment paramFragment);
  
  public abstract Fragment a(int paramInt);
  
  public abstract Fragment a(Bundle paramBundle, String paramString);
  
  public abstract Fragment a(String paramString);
  
  public abstract av a();
  
  public abstract void a(int paramInt1, int paramInt2);
  
  public abstract void a(Bundle paramBundle, String paramString, Fragment paramFragment);
  
  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract boolean b();
  
  public abstract boolean c();
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\ah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */