package android.support.v4.app;

import android.support.v4.g.a;
import android.view.View;
import java.util.ArrayList;

public final class r
{
  public a<String, String> a = new a();
  public ArrayList<View> b = new ArrayList();
  public bb c = new bb();
  public View d;
  
  public r(m paramm) {}
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */