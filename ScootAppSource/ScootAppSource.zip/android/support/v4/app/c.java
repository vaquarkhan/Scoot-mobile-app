package android.support.v4.app;

public abstract interface c
{
  public abstract void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfInt);
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */