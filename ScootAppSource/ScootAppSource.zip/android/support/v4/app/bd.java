package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.b.n;

public abstract class bd
{
  public abstract <D> n<D> a(int paramInt, Bundle paramBundle, be<D> parambe);
  
  public boolean a()
  {
    return false;
  }
  
  public abstract <D> n<D> b(int paramInt, Bundle paramBundle, be<D> parambe);
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\bd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */