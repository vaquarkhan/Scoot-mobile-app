package android.support.v4.app;

import android.view.View;

final class n
  implements bc
{
  n(m paramm, Fragment paramFragment) {}
  
  public View a()
  {
    return this.a.v();
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */