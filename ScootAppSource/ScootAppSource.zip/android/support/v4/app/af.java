package android.support.v4.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.support.v4.g.q;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public final class af
{
  private final ag<?> a;
  
  private af(ag<?> paramag)
  {
    this.a = paramag;
  }
  
  public static final af a(ag<?> paramag)
  {
    return new af(paramag);
  }
  
  Fragment a(String paramString)
  {
    return this.a.d.b(paramString);
  }
  
  public ah a()
  {
    return this.a.i();
  }
  
  public View a(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    return this.a.d.a(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public void a(Configuration paramConfiguration)
  {
    this.a.d.a(paramConfiguration);
  }
  
  public void a(Parcelable paramParcelable, List<Fragment> paramList)
  {
    this.a.d.a(paramParcelable, paramList);
  }
  
  public void a(Fragment paramFragment)
  {
    this.a.d.a(this.a, this.a, paramFragment);
  }
  
  public void a(q<String, bd> paramq)
  {
    this.a.a(paramq);
  }
  
  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    this.a.b(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public void a(boolean paramBoolean)
  {
    this.a.a(paramBoolean);
  }
  
  public boolean a(Menu paramMenu)
  {
    return this.a.d.a(paramMenu);
  }
  
  public boolean a(Menu paramMenu, MenuInflater paramMenuInflater)
  {
    return this.a.d.a(paramMenu, paramMenuInflater);
  }
  
  public boolean a(MenuItem paramMenuItem)
  {
    return this.a.d.a(paramMenuItem);
  }
  
  public bd b()
  {
    return this.a.j();
  }
  
  public void b(Menu paramMenu)
  {
    this.a.d.b(paramMenu);
  }
  
  public boolean b(MenuItem paramMenuItem)
  {
    return this.a.d.b(paramMenuItem);
  }
  
  public void c()
  {
    this.a.d.i();
  }
  
  public Parcelable d()
  {
    return this.a.d.h();
  }
  
  public List<Fragment> e()
  {
    return this.a.d.g();
  }
  
  public void f()
  {
    this.a.d.j();
  }
  
  public void g()
  {
    this.a.d.k();
  }
  
  public void h()
  {
    this.a.d.l();
  }
  
  public void i()
  {
    this.a.d.m();
  }
  
  public void j()
  {
    this.a.d.n();
  }
  
  public void k()
  {
    this.a.d.o();
  }
  
  public void l()
  {
    this.a.d.p();
  }
  
  public void m()
  {
    this.a.d.r();
  }
  
  public void n()
  {
    this.a.d.s();
  }
  
  public boolean o()
  {
    return this.a.d.e();
  }
  
  public void p()
  {
    this.a.l();
  }
  
  public void q()
  {
    this.a.m();
  }
  
  public void r()
  {
    this.a.n();
  }
  
  public q<String, bd> s()
  {
    return this.a.o();
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\af.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */