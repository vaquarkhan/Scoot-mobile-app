package android.support.v4.app;

public abstract class av
{
  public abstract int a();
  
  public abstract av a(int paramInt1, int paramInt2);
  
  public abstract av a(int paramInt, Fragment paramFragment);
  
  public abstract av a(int paramInt, Fragment paramFragment, String paramString);
  
  public abstract av a(Fragment paramFragment);
  
  public abstract av a(Fragment paramFragment, String paramString);
  
  public abstract int b();
  
  public abstract av b(Fragment paramFragment);
  
  public abstract av c(Fragment paramFragment);
  
  public abstract av d(Fragment paramFragment);
  
  public abstract av e(Fragment paramFragment);
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\av.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */