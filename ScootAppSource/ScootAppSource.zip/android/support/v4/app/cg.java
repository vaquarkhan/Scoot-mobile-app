package android.support.v4.app;

public abstract class cg
{
  CharSequence d;
  CharSequence e;
  boolean f = false;
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\cg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */