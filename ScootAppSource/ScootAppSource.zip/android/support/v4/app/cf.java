package android.support.v4.app;

import android.app.Notification;

class cf
  extends ce
{
  public Notification a(bu parambu, bv parambv)
  {
    cv localcv = new cv(parambu.a, parambu.B, parambu.b, parambu.c, parambu.h, parambu.f, parambu.i, parambu.d, parambu.e, parambu.g, parambu.o, parambu.p, parambu.q, parambu.k, parambu.l, parambu.j, parambu.n, parambu.v, parambu.C, parambu.x, parambu.r, parambu.s, parambu.t);
    bp.a(localcv, parambu.u);
    bp.a(localcv, parambu.m);
    return parambv.a(parambu, localcv);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\cf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */