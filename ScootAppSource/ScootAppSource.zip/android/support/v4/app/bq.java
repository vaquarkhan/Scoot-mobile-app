package android.support.v4.app;

import android.app.PendingIntent;
import android.os.Bundle;

public final class bq
  extends cm
{
  public static final cn d = new br();
  public int a;
  public CharSequence b;
  public PendingIntent c;
  private final Bundle e;
  private final cw[] f;
  
  public int a()
  {
    return this.a;
  }
  
  public CharSequence b()
  {
    return this.b;
  }
  
  public PendingIntent c()
  {
    return this.c;
  }
  
  public Bundle d()
  {
    return this.e;
  }
  
  public cw[] e()
  {
    return this.f;
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\bq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */