package android.support.v4.app;

import android.app.Notification;

final class cd
  extends ca
{
  public Notification a(bu parambu, bv parambv)
  {
    return parambv.a(parambu, new cr(parambu.a, parambu.B, parambu.b, parambu.c, parambu.h, parambu.f, parambu.i, parambu.d, parambu.e, parambu.g, parambu.o, parambu.p, parambu.q));
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\cd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */