package android.support.v4.app;

import android.os.Bundle;

public abstract class de
{
  protected abstract String a();
  
  protected abstract CharSequence b();
  
  protected abstract CharSequence[] c();
  
  protected abstract boolean d();
  
  protected abstract Bundle e();
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\de.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */