package android.support.v4.b;

import android.content.ComponentName;
import android.content.Intent;

class k
  extends j
{
  public Intent a(ComponentName paramComponentName)
  {
    return m.a(paramComponentName);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\b\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */