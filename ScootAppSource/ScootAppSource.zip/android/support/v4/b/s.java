package android.support.v4.b;

import android.content.Intent;
import java.util.ArrayList;

final class s
{
  final Intent a;
  final ArrayList<t> b;
  
  s(Intent paramIntent, ArrayList<t> paramArrayList)
  {
    this.a = paramIntent;
    this.b = paramArrayList;
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\b\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */