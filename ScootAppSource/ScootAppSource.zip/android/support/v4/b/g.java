package android.support.v4.b;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

final class g
{
  public static void a(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle)
  {
    paramContext.startActivities(paramArrayOfIntent, paramBundle);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\b\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */