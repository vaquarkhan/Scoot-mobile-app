package android.support.v4.f;

import java.util.Locale;

final class p
  extends n
{
  public static final p a = new p();
  
  public p()
  {
    super(null);
  }
  
  protected boolean a()
  {
    return q.a(Locale.getDefault()) == 1;
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\f\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */