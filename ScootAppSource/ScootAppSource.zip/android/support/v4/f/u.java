package android.support.v4.f;

import android.text.TextUtils;
import java.util.Locale;

final class u
{
  public static int a(Locale paramLocale)
  {
    return TextUtils.getLayoutDirectionFromLocale(paramLocale);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\f\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */