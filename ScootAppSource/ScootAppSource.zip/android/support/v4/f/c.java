package android.support.v4.f;

import java.util.Locale;

final class c
  implements b
{
  public String a(Locale paramLocale)
  {
    return null;
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\f\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */