package android.support.v4.f;

public final class i
{
  public static final h a = new o(null, false, null);
  public static final h b = new o(null, true, null);
  public static final h c = new o(l.a, false, null);
  public static final h d = new o(l.a, true, null);
  public static final h e = new o(k.a, false, null);
  public static final h f = p.a;
  
  private static int c(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return 2;
    case 0: 
      return 1;
    }
    return 0;
  }
  
  private static int d(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return 2;
    case 0: 
    case 14: 
    case 15: 
      return 1;
    }
    return 0;
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\f\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */