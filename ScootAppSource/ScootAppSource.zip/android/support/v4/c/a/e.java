package android.support.v4.c.a;

import android.graphics.drawable.Drawable;

class e
  extends d
{
  public void a(Drawable paramDrawable)
  {
    m.a(paramDrawable);
  }
  
  public Drawable c(Drawable paramDrawable)
  {
    return m.b(paramDrawable);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\c\a\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */