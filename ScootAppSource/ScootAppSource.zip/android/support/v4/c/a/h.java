package android.support.v4.c.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import org.xmlpull.v1.XmlPullParser;

class h
  extends g
{
  public void a(Drawable paramDrawable, float paramFloat1, float paramFloat2)
  {
    p.a(paramDrawable, paramFloat1, paramFloat2);
  }
  
  public void a(Drawable paramDrawable, int paramInt)
  {
    p.a(paramDrawable, paramInt);
  }
  
  public void a(Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    p.a(paramDrawable, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void a(Drawable paramDrawable, ColorStateList paramColorStateList)
  {
    p.a(paramDrawable, paramColorStateList);
  }
  
  public void a(Drawable paramDrawable, Resources.Theme paramTheme)
  {
    p.a(paramDrawable, paramTheme);
  }
  
  public void a(Drawable paramDrawable, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    p.a(paramDrawable, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
  }
  
  public void a(Drawable paramDrawable, PorterDuff.Mode paramMode)
  {
    p.a(paramDrawable, paramMode);
  }
  
  public Drawable c(Drawable paramDrawable)
  {
    return p.a(paramDrawable);
  }
  
  public boolean f(Drawable paramDrawable)
  {
    return p.b(paramDrawable);
  }
  
  public ColorFilter g(Drawable paramDrawable)
  {
    return p.c(paramDrawable);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\c\a\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */