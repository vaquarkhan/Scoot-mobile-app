package android.support.v4.c.a;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;

class w
  extends r
{
  w(Drawable paramDrawable)
  {
    super(paramDrawable);
  }
  
  w(s params, Resources paramResources)
  {
    super(params, paramResources);
  }
  
  s b()
  {
    return new x(this.b, null);
  }
  
  public void jumpToCurrentState()
  {
    this.c.jumpToCurrentState();
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\c\a\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */