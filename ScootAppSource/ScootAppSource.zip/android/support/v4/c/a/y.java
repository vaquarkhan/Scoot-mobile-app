package android.support.v4.c.a;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;

class y
  extends w
{
  y(Drawable paramDrawable)
  {
    super(paramDrawable);
  }
  
  y(s params, Resources paramResources)
  {
    super(params, paramResources);
  }
  
  s b()
  {
    return new z(this.b, null);
  }
  
  public boolean isAutoMirrored()
  {
    return this.c.isAutoMirrored();
  }
  
  public void setAutoMirrored(boolean paramBoolean)
  {
    this.c.setAutoMirrored(paramBoolean);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\c\a\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */