package android.support.v4.c.a;

import android.graphics.drawable.Drawable;

class d
  extends b
{
  public Drawable c(Drawable paramDrawable)
  {
    return l.a(paramDrawable);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\c\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */