package android.support.v4.c.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import org.xmlpull.v1.XmlPullParser;

class b
  implements c
{
  public void a(Drawable paramDrawable) {}
  
  public void a(Drawable paramDrawable, float paramFloat1, float paramFloat2) {}
  
  public void a(Drawable paramDrawable, int paramInt)
  {
    k.a(paramDrawable, paramInt);
  }
  
  public void a(Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void a(Drawable paramDrawable, ColorStateList paramColorStateList)
  {
    k.a(paramDrawable, paramColorStateList);
  }
  
  public void a(Drawable paramDrawable, Resources.Theme paramTheme) {}
  
  public void a(Drawable paramDrawable, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    k.a(paramDrawable, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
  }
  
  public void a(Drawable paramDrawable, PorterDuff.Mode paramMode)
  {
    k.a(paramDrawable, paramMode);
  }
  
  public void a(Drawable paramDrawable, boolean paramBoolean) {}
  
  public void b(Drawable paramDrawable, int paramInt) {}
  
  public boolean b(Drawable paramDrawable)
  {
    return false;
  }
  
  public Drawable c(Drawable paramDrawable)
  {
    return k.a(paramDrawable);
  }
  
  public int d(Drawable paramDrawable)
  {
    return 0;
  }
  
  public int e(Drawable paramDrawable)
  {
    return 0;
  }
  
  public boolean f(Drawable paramDrawable)
  {
    return false;
  }
  
  public ColorFilter g(Drawable paramDrawable)
  {
    return null;
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\c\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */