package android.support.v4.c.a;

import android.graphics.drawable.Drawable;

public abstract interface q
{
  public abstract Drawable a();
  
  public abstract void a(Drawable paramDrawable);
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\c\a\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */