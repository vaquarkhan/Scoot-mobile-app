package android.support.v4.view.a;

class u
  extends t
{
  public Object a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2)
  {
    return ad.a(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean1);
  }
  
  public Object a(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3)
  {
    return ad.a(paramInt1, paramInt2, paramBoolean, paramInt3);
  }
  
  public void b(Object paramObject1, Object paramObject2)
  {
    ad.a(paramObject1, paramObject2);
  }
  
  public void c(Object paramObject1, Object paramObject2)
  {
    ad.b(paramObject1, paramObject2);
  }
  
  public void j(Object paramObject, boolean paramBoolean)
  {
    ad.a(paramObject, paramBoolean);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */