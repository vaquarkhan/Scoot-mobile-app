package android.support.v4.view.a;

class as
  extends aw
{
  public void a(Object paramObject, int paramInt)
  {
    ax.a(paramObject, paramInt);
  }
  
  public void a(Object paramObject, boolean paramBoolean)
  {
    ax.a(paramObject, paramBoolean);
  }
  
  public void b(Object paramObject, int paramInt)
  {
    ax.b(paramObject, paramInt);
  }
  
  public void c(Object paramObject, int paramInt)
  {
    ax.c(paramObject, paramInt);
  }
  
  public void d(Object paramObject, int paramInt)
  {
    ax.d(paramObject, paramInt);
  }
  
  public void e(Object paramObject, int paramInt)
  {
    ax.e(paramObject, paramInt);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\as.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */