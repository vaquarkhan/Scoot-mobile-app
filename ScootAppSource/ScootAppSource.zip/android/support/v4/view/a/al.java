package android.support.v4.view.a;

final class al
{
  public static Object a(an paraman)
  {
    return new am(paraman);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */