package android.support.v4.view.a;

import android.view.accessibility.AccessibilityEvent;

final class f
{
  public static int a(AccessibilityEvent paramAccessibilityEvent)
  {
    return paramAccessibilityEvent.getContentChangeTypes();
  }
  
  public static void a(AccessibilityEvent paramAccessibilityEvent, int paramInt)
  {
    paramAccessibilityEvent.setContentChangeTypes(paramInt);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */