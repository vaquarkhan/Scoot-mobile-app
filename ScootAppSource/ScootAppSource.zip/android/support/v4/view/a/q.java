package android.support.v4.view.a;

import android.graphics.Rect;
import android.view.View;

abstract interface q
{
  public abstract Object a();
  
  public abstract Object a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract Object a(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3);
  
  public abstract Object a(int paramInt, CharSequence paramCharSequence);
  
  public abstract Object a(View paramView);
  
  public abstract Object a(Object paramObject);
  
  public abstract void a(Object paramObject, int paramInt);
  
  public abstract void a(Object paramObject, Rect paramRect);
  
  public abstract void a(Object paramObject, View paramView);
  
  public abstract void a(Object paramObject, View paramView, int paramInt);
  
  public abstract void a(Object paramObject, CharSequence paramCharSequence);
  
  public abstract void a(Object paramObject, boolean paramBoolean);
  
  public abstract boolean a(Object paramObject1, Object paramObject2);
  
  public abstract int b(Object paramObject);
  
  public abstract void b(Object paramObject, Rect paramRect);
  
  public abstract void b(Object paramObject, View paramView);
  
  public abstract void b(Object paramObject, View paramView, int paramInt);
  
  public abstract void b(Object paramObject, CharSequence paramCharSequence);
  
  public abstract void b(Object paramObject1, Object paramObject2);
  
  public abstract void b(Object paramObject, boolean paramBoolean);
  
  public abstract CharSequence c(Object paramObject);
  
  public abstract void c(Object paramObject, Rect paramRect);
  
  public abstract void c(Object paramObject, View paramView);
  
  public abstract void c(Object paramObject, CharSequence paramCharSequence);
  
  public abstract void c(Object paramObject1, Object paramObject2);
  
  public abstract void c(Object paramObject, boolean paramBoolean);
  
  public abstract CharSequence d(Object paramObject);
  
  public abstract void d(Object paramObject, Rect paramRect);
  
  public abstract void d(Object paramObject, View paramView);
  
  public abstract void d(Object paramObject, CharSequence paramCharSequence);
  
  public abstract void d(Object paramObject, boolean paramBoolean);
  
  public abstract CharSequence e(Object paramObject);
  
  public abstract void e(Object paramObject, CharSequence paramCharSequence);
  
  public abstract void e(Object paramObject, boolean paramBoolean);
  
  public abstract CharSequence f(Object paramObject);
  
  public abstract void f(Object paramObject, boolean paramBoolean);
  
  public abstract void g(Object paramObject, boolean paramBoolean);
  
  public abstract boolean g(Object paramObject);
  
  public abstract void h(Object paramObject, boolean paramBoolean);
  
  public abstract boolean h(Object paramObject);
  
  public abstract void i(Object paramObject, boolean paramBoolean);
  
  public abstract boolean i(Object paramObject);
  
  public abstract void j(Object paramObject, boolean paramBoolean);
  
  public abstract boolean j(Object paramObject);
  
  public abstract boolean k(Object paramObject);
  
  public abstract boolean l(Object paramObject);
  
  public abstract boolean m(Object paramObject);
  
  public abstract boolean n(Object paramObject);
  
  public abstract boolean o(Object paramObject);
  
  public abstract boolean p(Object paramObject);
  
  public abstract void q(Object paramObject);
  
  public abstract boolean r(Object paramObject);
  
  public abstract boolean s(Object paramObject);
  
  public abstract String t(Object paramObject);
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */