package android.support.v4.view.a;

import android.view.View;

abstract interface au
{
  public abstract void a(Object paramObject, int paramInt);
  
  public abstract void a(Object paramObject, View paramView, int paramInt);
  
  public abstract void a(Object paramObject, boolean paramBoolean);
  
  public abstract void b(Object paramObject, int paramInt);
  
  public abstract void c(Object paramObject, int paramInt);
  
  public abstract void d(Object paramObject, int paramInt);
  
  public abstract void e(Object paramObject, int paramInt);
  
  public abstract void f(Object paramObject, int paramInt);
  
  public abstract void g(Object paramObject, int paramInt);
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\au.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */