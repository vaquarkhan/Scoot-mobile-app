package android.support.v4.view.a;

public final class m
{
  public static final m a = new m(1, null);
  public static final m b = new m(2, null);
  public static final m c = new m(4, null);
  public static final m d = new m(8, null);
  public static final m e = new m(16, null);
  public static final m f = new m(32, null);
  public static final m g = new m(64, null);
  public static final m h = new m(128, null);
  public static final m i = new m(256, null);
  public static final m j = new m(512, null);
  public static final m k = new m(1024, null);
  public static final m l = new m(2048, null);
  public static final m m = new m(4096, null);
  public static final m n = new m(8192, null);
  public static final m o = new m(16384, null);
  public static final m p = new m(32768, null);
  public static final m q = new m(65536, null);
  public static final m r = new m(131072, null);
  public static final m s = new m(262144, null);
  public static final m t = new m(524288, null);
  public static final m u = new m(1048576, null);
  public static final m v = new m(2097152, null);
  private final Object w;
  
  public m(int paramInt, CharSequence paramCharSequence)
  {
    this(l.v().a(paramInt, paramCharSequence));
  }
  
  private m(Object paramObject)
  {
    this.w = paramObject;
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */