package android.support.v4.view.a;

import android.os.Bundle;
import java.util.List;

abstract interface aq
{
  public abstract Object a(int paramInt);
  
  public abstract List<Object> a(String paramString, int paramInt);
  
  public abstract boolean a(int paramInt1, int paramInt2, Bundle paramBundle);
  
  public abstract Object b(int paramInt);
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\aq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */