package android.support.v4.view.a;

import android.graphics.Rect;
import android.view.View;

class p
  extends v
{
  public Object a()
  {
    return z.a();
  }
  
  public Object a(View paramView)
  {
    return z.a(paramView);
  }
  
  public Object a(Object paramObject)
  {
    return z.a(paramObject);
  }
  
  public void a(Object paramObject, int paramInt)
  {
    z.a(paramObject, paramInt);
  }
  
  public void a(Object paramObject, Rect paramRect)
  {
    z.a(paramObject, paramRect);
  }
  
  public void a(Object paramObject, View paramView)
  {
    z.a(paramObject, paramView);
  }
  
  public void a(Object paramObject, boolean paramBoolean)
  {
    z.a(paramObject, paramBoolean);
  }
  
  public int b(Object paramObject)
  {
    return z.b(paramObject);
  }
  
  public void b(Object paramObject, Rect paramRect)
  {
    z.b(paramObject, paramRect);
  }
  
  public void b(Object paramObject, View paramView)
  {
    z.b(paramObject, paramView);
  }
  
  public void b(Object paramObject, CharSequence paramCharSequence)
  {
    z.a(paramObject, paramCharSequence);
  }
  
  public void b(Object paramObject, boolean paramBoolean)
  {
    z.b(paramObject, paramBoolean);
  }
  
  public CharSequence c(Object paramObject)
  {
    return z.c(paramObject);
  }
  
  public void c(Object paramObject, Rect paramRect)
  {
    z.c(paramObject, paramRect);
  }
  
  public void c(Object paramObject, View paramView)
  {
    z.c(paramObject, paramView);
  }
  
  public void c(Object paramObject, CharSequence paramCharSequence)
  {
    z.b(paramObject, paramCharSequence);
  }
  
  public void c(Object paramObject, boolean paramBoolean)
  {
    z.c(paramObject, paramBoolean);
  }
  
  public CharSequence d(Object paramObject)
  {
    return z.d(paramObject);
  }
  
  public void d(Object paramObject, Rect paramRect)
  {
    z.d(paramObject, paramRect);
  }
  
  public void d(Object paramObject, CharSequence paramCharSequence)
  {
    z.c(paramObject, paramCharSequence);
  }
  
  public void d(Object paramObject, boolean paramBoolean)
  {
    z.d(paramObject, paramBoolean);
  }
  
  public CharSequence e(Object paramObject)
  {
    return z.e(paramObject);
  }
  
  public void e(Object paramObject, CharSequence paramCharSequence)
  {
    z.d(paramObject, paramCharSequence);
  }
  
  public void e(Object paramObject, boolean paramBoolean)
  {
    z.e(paramObject, paramBoolean);
  }
  
  public CharSequence f(Object paramObject)
  {
    return z.f(paramObject);
  }
  
  public void f(Object paramObject, boolean paramBoolean)
  {
    z.f(paramObject, paramBoolean);
  }
  
  public void g(Object paramObject, boolean paramBoolean)
  {
    z.g(paramObject, paramBoolean);
  }
  
  public boolean g(Object paramObject)
  {
    return z.g(paramObject);
  }
  
  public boolean h(Object paramObject)
  {
    return z.h(paramObject);
  }
  
  public boolean i(Object paramObject)
  {
    return z.i(paramObject);
  }
  
  public boolean j(Object paramObject)
  {
    return z.j(paramObject);
  }
  
  public boolean k(Object paramObject)
  {
    return z.k(paramObject);
  }
  
  public boolean l(Object paramObject)
  {
    return z.l(paramObject);
  }
  
  public boolean m(Object paramObject)
  {
    return z.m(paramObject);
  }
  
  public boolean n(Object paramObject)
  {
    return z.n(paramObject);
  }
  
  public boolean o(Object paramObject)
  {
    return z.o(paramObject);
  }
  
  public boolean p(Object paramObject)
  {
    return z.p(paramObject);
  }
  
  public void q(Object paramObject)
  {
    z.q(paramObject);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */