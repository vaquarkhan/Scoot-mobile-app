package android.support.v4.view.a;

import android.view.View;

class s
  extends r
{
  public void d(Object paramObject, View paramView)
  {
    ab.a(paramObject, paramView);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */