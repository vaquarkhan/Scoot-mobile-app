package android.support.v4.view.a;

public final class w
{
  final Object a;
  
  private w(Object paramObject)
  {
    this.a = paramObject;
  }
  
  public static w a(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3)
  {
    return new w(l.v().a(paramInt1, paramInt2, paramBoolean, paramInt3));
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */