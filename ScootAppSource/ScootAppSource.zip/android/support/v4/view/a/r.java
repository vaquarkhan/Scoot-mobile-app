package android.support.v4.view.a;

import android.view.View;

class r
  extends p
{
  public void a(Object paramObject, View paramView, int paramInt)
  {
    aa.b(paramObject, paramView, paramInt);
  }
  
  public void b(Object paramObject, View paramView, int paramInt)
  {
    aa.a(paramObject, paramView, paramInt);
  }
  
  public void h(Object paramObject, boolean paramBoolean)
  {
    aa.a(paramObject, paramBoolean);
  }
  
  public void i(Object paramObject, boolean paramBoolean)
  {
    aa.b(paramObject, paramBoolean);
  }
  
  public boolean r(Object paramObject)
  {
    return aa.a(paramObject);
  }
  
  public boolean s(Object paramObject)
  {
    return aa.b(paramObject);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */