package android.support.v4.view.a;

import android.view.accessibility.AccessibilityEvent;

abstract interface e
{
  public abstract int a(AccessibilityEvent paramAccessibilityEvent);
  
  public abstract void a(AccessibilityEvent paramAccessibilityEvent, int paramInt);
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */