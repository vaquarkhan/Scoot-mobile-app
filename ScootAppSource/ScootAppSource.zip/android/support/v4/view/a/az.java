package android.support.v4.view.a;

import android.view.View;
import android.view.accessibility.AccessibilityRecord;

final class az
{
  public static void a(Object paramObject, View paramView, int paramInt)
  {
    ((AccessibilityRecord)paramObject).setSource(paramView, paramInt);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\az.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */