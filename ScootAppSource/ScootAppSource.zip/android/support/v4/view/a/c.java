package android.support.v4.view.a;

import android.view.accessibility.AccessibilityEvent;

final class c
  extends b
{
  public int a(AccessibilityEvent paramAccessibilityEvent)
  {
    return f.a(paramAccessibilityEvent);
  }
  
  public void a(AccessibilityEvent paramAccessibilityEvent, int paramInt)
  {
    f.a(paramAccessibilityEvent, paramInt);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */