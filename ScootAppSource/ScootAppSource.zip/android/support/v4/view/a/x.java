package android.support.v4.view.a;

public final class x
{
  private final Object a;
  
  private x(Object paramObject)
  {
    this.a = paramObject;
  }
  
  public static x a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2)
  {
    return new x(l.v().a(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean1, paramBoolean2));
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\a\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */