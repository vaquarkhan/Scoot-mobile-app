package android.support.b;

import android.app.Application;
import android.content.Context;

public class e
  extends Application
{
  protected void attachBaseContext(Context paramContext)
  {
    super.attachBaseContext(paramContext);
    a.a(this);
  }
}


/* Location:              D:\Android\dex2jar-2.0\classes-dex2jar.jar!\android\support\b\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */